﻿Imports System.ComponentModel

Public Class Form1
    Dim WithEvents newupdate As New UpdateLib.AppUpdate
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        SaveFileDialog1.ShowDialog()
    End Sub

    Private Sub SaveFileDialog1_FileOk(sender As Object, e As CancelEventArgs) Handles SaveFileDialog1.FileOk
        TextBox2.Text = SaveFileDialog1.FileName
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox2.Text = My.Computer.FileSystem.SpecialDirectories.Temp & "\update.zip"
        TextBox3.Text = My.Computer.FileSystem.SpecialDirectories.Temp & "\update.zip"
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        FolderBrowserDialog1.ShowDialog()
        If My.Computer.FileSystem.DirectoryExists(FolderBrowserDialog1.SelectedPath) Then
            TextBox4.Text = FolderBrowserDialog1.SelectedPath
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        newupdate.ZipDownload(TextBox1.Text, TextBox2.Text)
    End Sub

    Private Sub update_DownloadProgress(progress_value As Integer, TotalBytes As Integer, bytes As Integer) Handles newupdate.DownloadProgress
        ProgressBar1.Value = progress_value
        Label5.Text = bytes & " von " & TotalBytes
    End Sub

    Private Sub update_DownloadFinish() Handles newupdate.DownloadFinish
        newupdate.extract_update(TextBox2.Text, TextBox4.Text, False, "")
    End Sub

    Private Sub update_extractUpdateComplete() Handles newupdate.extractUpdateComplete
        MsgBox("Update abgeschlossen!", MsgBoxStyle.Information)
    End Sub
End Class
